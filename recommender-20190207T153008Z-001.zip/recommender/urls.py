from django.conf.urls import url

from . import views
urlpatterns=[
    url(r'^$',views.index, name='index'),
        url('login',views.login,name='login'),
          url('form',views.get_name,name='get name'),
              url('showdata',views.showdata,name='data'),
                url('pythonsolr',views.pythonsolr,name='pythonsolr'),]
