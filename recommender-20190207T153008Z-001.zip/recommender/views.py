from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from .forms import NameForm
from userprofile.models import uprofile
from django.views.generic.edit import CreateView
import pandas as pd
import pysolr

#from django.template import loader

# Create your views here.

def index(request):
    #template = loader.get_template("index.html")
    #return HttpResponse("Hello, world. You're at the polls index.")
    #return HttpResponse(template.render())
    return render(request,"index.html")
def login(request):

     return render(request,"index.html",{"abc":"hkj"})

def get_name(request):
    # if this is a POST request we need to process the form data
    if request.method == 'POST':
        # create a form instance and populate it with data from the request:
        form = NameForm(request.POST)
        # check whether it's valid:
        if form.is_valid():
            a= form.cleaned_data['your_name']
            b=form.cleaned_data['userid']
            c=form.cleaned_data['gender']
            d=form.cleaned_data['city']
            up=uprofile(name=a,user_id=b,gndr=c,loctn=d)
            up.save()
            # process the data in form.cleaned_data as required
            # ...
            # redirect to a new URL:
            return HttpResponseRedirect('/thanks/')

    # if a GET (or any other method) we'll create a blank form
    else:
        form = NameForm()

    return render(request, 'index.html', {'form': form})


def showdata(request):
    up=uprofile.objects.all()
    #n=''
    
    
    
        #print str(i.name),str(i.user_id),str(i.gndr),str(i.loctn)
        #n=n+str(i.name)+str(i.user_id)+str(i.gndr)+str(i.loctn)
    return render(request, 'index.html',{'data': up})

def pythonsolr(request):
    solrcon = pysolr.Solr('http://localhost:8983/solr/collection1/', timeout=10)
    results = solrcon.search('*:*')
    docs = pd.DataFrame(results.docs)
    t=results.docs[0]['url']
    t1="<a href='"+t+"'>"+t+"</a>"
    return render(request, 'index.html',{'data': t1})
    


    
