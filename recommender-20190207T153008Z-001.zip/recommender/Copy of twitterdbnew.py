from tweepy import Stream
from tweepy import OAuthHandler
from tweepy.streaming import StreamListener
import mysql.connector
from mysql.connector import errorcode
import time
import json



# replace mysql.server with "localhost" 
# if you are running via your own server!
# server       MySQL username	MySQL pass  Database name.

config={
    'user':'root',
    'password':'',
    'host':'127.0.0.1',
    'database':'world',
    'charset':'utf8mb4',
    'raise_on_warnings':True,
    }
cnx=mysql.connector.connect(**config)
cursor=cnx.cursor()


#consumer key, consumer secret, access token, access secret.
ckey="WUo9kbn3UFqU7TxSJow7jfCgi"
csecret="NwI5EcQbWBKgZHMlTNVVRNLCHRVBV9m26WSHr8OB5OXYWx8Ane"
atoken="842634564631740417-qMCNDF2oqY8Mg8LaXxtg2a70Oomyv5P"
asecret="FCseYN23NCDocwZpry52JEPWlT3JgAO81c0zDdVIQ0TQS"


class listener(StreamListener):

    def on_data(self, data):
        all_data = json.loads(data)
        
        # check to ensure there is text in 
        # the json data
        if 'text' in all_data:
          tweet = all_data["text"]
          user = all_data["user"]["screen_name"]
          
          cursor.execute(
            "INSERT INTO twitter (time1, user, tweet) VALUES (%s,%s,%s)",
            ( time.time(),user, tweet))
          
          cnx.commit()
          
          print((user,tweet))
          
          return True
        else:
          return True

    def on_error(self, status):
        print(status)

auth = OAuthHandler(ckey, csecret)
auth.set_access_token(atoken, asecret)

twitterStream = Stream(auth, listener())
twitterStream.filter(track=["car"],
  languages = ["en"], stall_warnings = True)
