from django.db import models

# Create your models here.

class uprofile(models.Model):
    name=models.CharField(max_length=200)
    
    user_id=models.IntegerField(default=0)

    gndr=models.CharField(max_length=2 , default='m')

    loctn=models.CharField(max_length=40, default='bbvn')


    
    def __str__(self):
        return self.name
        

